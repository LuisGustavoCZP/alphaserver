function PageConsulta () {
    window.location.href="/consulta";
}

function PageRegistro () {
    window.location.href="/registro";
}